@extends('layouts.app')

@section('content')
<section class="legal-hero"><div class="wrap wrap--narrow">
    @include('partials.breadcrumbs')
    <p class="eyebrow">Legal</p>
    <h1 class="display-h">Privacy <em>Policy</em></h1>
    <p class="mono-note">Last updated: October 2026</p>
</div></section>

<section class="section legal">
    <div class="wrap wrap--narrow">
        <p class="lead-p">{{ config('site.legal_name') }} ("Architive", "we", "us") respects your privacy. This policy explains what information we collect through this website, how we use it and the choices you have.</p>

        <h2>Information we collect</h2>
        <p>We collect only what you choose to send us: your name, email address, company, role, project details, target deadline and any links to files or references you include in the enquiry form or in an email to {{ config('site.email') }}.</p>

        <h2>How we use it</h2>
        <ul>
            <li>To reply to your enquiry and recommend a practical scope.</li>
            <li>To prepare a written quotation and, if you proceed, to carry out the agreed work.</li>
            <li>To keep a record of our communication with you.</li>
        </ul>
        <p>We do not sell your personal information.</p>

        <h2>Project files and confidentiality</h2>
        <p>Detailed project files are shared only through a transfer method confirmed with you. If you ask for it, we will review and sign a mutual NDA before detailed project information is shared. Project access is limited to the assigned team.</p>
        <p>Drawings, city comment letters and other files you upload through our enquiry forms (including the Permit Revisions form) are stored privately. They are not public and are opened only by our team and the people working on your request, and they may be copied to Architive's private cloud storage (Google Drive) as a backup. We do not send uploaded files to third-party artificial intelligence services; if that ever changes, we will update this policy first and ask you. You can ask us to delete your uploaded files, or your request, at any time using the email address below.</p>

        <h2>Cookies and local storage</h2>
        <p>Apart from the third-party services described below (Google Analytics, Google Ads, Google reCAPTCHA and Tawk.to live chat), this website stores a few items in your browser's local storage: your light or dark theme choice; for visitors in the EU and the UK, your answer to our cookie notice, so the site does not ask again; and, if you arrived from an ad or a link with campaign tags, that campaign's name and the page you landed on, which are sent with your enquiry so we know which ad brought it. They are deleted after 90 days and are not used to track you across other websites.</p>

        <h2>Analytics and advertising (Google Analytics and Google Ads)</h2>
        <p>We use Google Ads to show ads for our services and to measure which ads lead to enquiries. When you send an enquiry or tap our phone, email or WhatsApp link, Google Ads is told that a conversion happened. To match it to the ad you clicked, your email address may be shared with Google in a scrambled (hashed) form, never in readable form. Google may also use your visit to show you our ads again later; you can control this in Google's <a href="https://adssettings.google.com" target="_blank" rel="noopener">ad settings</a>. The same consent rules as for analytics below apply.</p>
        <p>We use Google Analytics 4 to see which pages are read, where visitors come from and whether enquiries are sent, so we can improve the site. We do not share your enquiry details with it. If you are in the European Union or the United Kingdom, we ask first: analytics cookies stay off until you press Accept, and you can change your mind with Cookie settings in the footer. Elsewhere we do not show a notice, and analytics is on; you can switch it off with the Google add-on linked below. Without your consent, Google may still receive limited, cookie-free signals such as the page viewed. Google processes this information under its own <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">privacy policy</a>. You can also block it with Google's <a href="https://tools.google.com/dlpage/gaoptout" target="_blank" rel="noopener">browser add-on</a>.</p>

        <h2>Spam protection (Google reCAPTCHA)</h2>
        <p>Our enquiry form is protected by Google reCAPTCHA (the "I'm not a robot" check) to stop automated spam. reCAPTCHA is only loaded where there is an enquiry form (the contact page, the enquiry pop-up and the Permit Revisions page). It may set cookies and collect technical information such as your IP address and how you interact with the check, which is sent to Google for that purpose. Google's use of this information is governed by the <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google Privacy Policy</a> and <a href="https://policies.google.com/terms" target="_blank" rel="noopener">Terms of Service</a>.</p>

        <h2>Live chat (Tawk.to)</h2>
        <p>This website offers a live chat powered by Tawk.to. When the chat loads or you use it, Tawk.to may set cookies and process technical information (such as your IP address, browser and the page you are viewing) and anything you type into the chat, including a name or email address if you share one. This is used to deliver the chat and let our team reply to you. Tawk.to handles this information under its own <a href="https://www.tawk.to/privacy-policy/" target="_blank" rel="noopener">privacy policy</a>.</p>

        <h2>Email notifications</h2>
        <p>When you send an enquiry, the details you entered are emailed to our team so we can reply to you. We do not add you to any mailing list.</p>

        <h2>Sharing</h2>
        <p>We share information only with the people and service providers who need it to respond to you or deliver the agreed work, and where required by law.</p>

        <h2>Retention</h2>
        <p>We keep enquiry and project records for as long as needed to respond, deliver the work and meet legal or accounting obligations, then delete or anonymize them.</p>

        <h2>Your choices</h2>
        <p>You may ask us to access, correct or delete the personal information we hold about you by emailing <a href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a>.</p>

        <h2>Contact</h2>
        <p>{{ config('site.legal_name') }}, Newark, Delaware, USA · <a href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a></p>
    </div>
</section>
@endsection
