<?php

use App\Http\Controllers\BlogController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PermitRevisionController;
use App\Http\Controllers\SeoController;
use App\Http\Middleware\EnsureTrailingSlash;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Architive – public site routes
|--------------------------------------------------------------------------
| URL structure follows the client's copy deck. Every page has exactly one
| permanent, lowercase, trailing-slash URL; the slash-less variant 301s to it.
*/

// Old WordPress-era addresses -> current pages (list in config/redirects.php).
// Absolute URL via away() so the trailing slash survives (redirect()->to() strips it and costs a second 301).
foreach (config('redirects', []) as $from => $to) {
    Route::any($from, fn (\Illuminate\Http\Request $r) => redirect()->away($r->getSchemeAndHttpHost() . $to, 301));
}

Route::middleware(EnsureTrailingSlash::class)->group(function () {
    Route::get('/', [PageController::class, 'home'])->name('home');
    Route::get('about-us/', [PageController::class, 'about'])->name('about');
    Route::get('team/', [PageController::class, 'team'])->name('team');

    Route::get('services/', [PageController::class, 'services'])->name('services.index');
    Route::get('architectural-visualization-rendering/', [PageController::class, 'visualization'])->name('services.visualization');
    Route::get('exterior-rendering-services/', [PageController::class, 'exterior'])->name('services.exterior');
    Route::get('interior-rendering-services/', [PageController::class, 'interior'])->name('services.interior');
    Route::get('3d-floor-plan-rendering-services/', [PageController::class, 'floorplans'])->name('services.floorplans');
    Route::get('architectural-animation-360-views/', [PageController::class, 'animation'])->name('services.animation');
    Route::get('rayon-cad-drafting-services/', [PageController::class, 'rayon'])->name('services.rayon');
    Route::get('outsource-architectural-visualization/', [PageController::class, 'outsourceVisualization'])->name('services.outsource-visualization');
    Route::get('bim-revit-scan-to-bim/', [PageController::class, 'bim'])->name('services.bim');
    Route::get('cad-drafting-services/', [PageController::class, 'cad'])->name('services.cad');
    Route::get('permit-revisions/', [PermitRevisionController::class, 'show'])->name('permit-revisions');
    // Production support is no longer a separate page: keep the old URL alive with a permanent redirect to Services.
    Route::get('architectural-outsourcing/', [PageController::class, 'outsourcing'])->name('services.outsourcing');

    Route::get('collaborations/', [PageController::class, 'collaborations'])->name('collaborations.index');
    Route::get('collaborations/{slug}/', [PageController::class, 'collaboration'])
        ->where('slug', '[a-z0-9\-]+')->name('collaborations.show');

    Route::get('blog/', [BlogController::class, 'index'])->name('blog.index');
    Route::get('blog/category/{slug}/', [BlogController::class, 'category'])->where('slug', '[a-z0-9\-]+')->name('blog.category');
    Route::get('blog/tag/{slug}/', [BlogController::class, 'tag'])->where('slug', '[a-z0-9\-]+')->name('blog.tag');
    Route::get('blog/{slug}/', [BlogController::class, 'show'])->where('slug', '[a-z0-9\-]+')->name('blog.show');

    Route::get('how-it-works/', [PageController::class, 'process'])->name('process');
    Route::get('faqs/', [PageController::class, 'faqs'])->name('faqs');
    Route::get('free-trial/', [PageController::class, 'freeTrial'])->name('free-trial');
    Route::get('what-we-need/', [PageController::class, 'whatWeNeed'])->name('what-we-need');
    Route::get('contact/', [PageController::class, 'contact'])->name('contact');

    Route::get('privacy-policy/', [PageController::class, 'privacy'])->name('privacy');
    Route::get('terms-of-service/', [PageController::class, 'terms'])->name('terms');
    Route::get('sitemap/', [PageController::class, 'sitemap'])->name('sitemap.html');

    // Google Ads landing pages (config/landing.php) and the post-enquiry thank-you page: noindex, not in the sitemap
    Route::get('lp/{slug}/', [PageController::class, 'landing'])->where('slug', '[a-z0-9\-]+')->name('lp');
    Route::get('thank-you/', [PageController::class, 'thanks'])->name('thanks');
});

Route::post('contact/send', [ContactController::class, 'store'])->middleware('throttle:6,1')->name('contact.send');
Route::post('permit-revisions/send', [PermitRevisionController::class, 'store'])->middleware('throttle:permit')->name('permit-revisions.send');

Route::get('blog/feed.xml', [BlogController::class, 'feed'])->name('blog.feed');
Route::get('sitemap.xml', [SeoController::class, 'sitemap'])->name('sitemap.xml');
Route::get('robots.txt', [SeoController::class, 'robots'])->name('robots');
