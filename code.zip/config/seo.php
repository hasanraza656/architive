<?php

/*
|--------------------------------------------------------------------------
| Per-page SEO metadata, keyed by route name
|--------------------------------------------------------------------------
| title / description for the first ten pages come straight from the client's
| approved copy deck. `image` is a path under /public (defaults to og-default).
| `sitemap` => [priority, changefreq] feeds /sitemap.xml.
*/

return [
    'default_image' => 'assets/img/og-default.jpg',
    'title_suffix'  => ' | Architive',

    'pages' => [
        'home' => [
            'title'       => 'Architectural Visualization, BIM and CAD | Architive',
            'description' => 'Architectural visualization, BIM and Revit, and CAD drafting for architecture firms, interior designers, developers and homeowners worldwide.',
            'sitemap'     => [1.0, 'weekly'],
        ],
        'blog.index' => [
            'title'       => 'Architectural Visualization, BIM and CAD Insights | Architive Blog',
            'description' => 'Practical guides on architectural visualization, BIM and Revit, and CAD drafting from the Architive studio: costs, workflows, file standards and how to brief a production team.',
            'sitemap'     => [0.8, 'daily'],
        ],
        'about' => [
            'title'       => 'Who We Are | About Architive, Architectural Production Studio',
            'description' => 'Meet Architive, an established architectural production studio providing visualization, BIM and Revit, and CAD drafting worldwide.',
            'image'       => 'assets/img/og/blueprint-tools.jpg',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'services.index' => [
            'title'       => 'Architectural Visualization, BIM and CAD Services | Architive',
            'description' => 'Three connected services—architectural visualization, BIM and Revit, and CAD drafting—plus flexible production support for architecture and design firms.',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.visualization' => [
            'title'       => 'Architectural Visualization and Rendering | Architive',
            'description' => 'Architectural visualization for design reviews, approvals and marketing, including interior and exterior renderings, 3D floor plans and renovation visuals.',
            'image'       => 'assets/img/og/viz-bandon.jpg',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.exterior' => [
            'title'       => 'Exterior Rendering Services and 3D Visualization | Architive',
            'description' => 'Photoreal exterior rendering services from your CAD or Revit files: hero, street, aerial and twilight views for approvals, planning and pre-sales.',
            'image'       => 'assets/img/og/viz-bandon.jpg',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'free-trial' => [
            'title'       => 'Free 3-Day Trial | Architive',
            'description' => 'Send one real task and we work on it free for up to 3 working days. Judge our quality, speed and communication. No card, no contract.',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'what-we-need' => [
            'title'       => 'What We Need From You | Architive',
            'description' => 'The files and details that help most for 3D floor plans, renders, CAD drafting and BIM. Send what you have and we tell you what is missing.',
            'sitemap'     => [0.7, 'monthly'],
        ],
        'services.interior' => [
            'title'       => '3D Interior Rendering Services | Architive',
            'description' => 'Photoreal 3D interior rendering services from your plans and finish schedule: kitchens, baths, living spaces and commercial interiors, with finish options.',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.floorplans' => [
            'title'       => '3D Floor Plan Rendering Services | Architive',
            'description' => 'Turn 2D floor plans into furnished 3D floor plans, top-down or isometric, for listings, brochures, leasing and client presentations.',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.outsource-visualization' => [
            'title'       => 'Outsource Architectural Visualization | Architive',
            'description' => 'Outsource exterior renders, interior renders and 3D floor plans. Send drawings, keep your clients and style, get a written quote first.',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.animation' => [
            'title'       => 'Architectural Animation and 360 Views | Architive',
            'description' => 'Architectural animation, walkthroughs and 360-degree views built from your drawings or model, so clients and buyers can explore a design before it is built.',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'services.rayon' => [
            'title'       => 'Rayon CAD Drafting Services for Interior Designers | Architive',
            'description' => 'Rayon drafting services: PDF, DWG and scan to Rayon drawings, template and block setup, furniture layouts, test fits and DWG exports for consultants.',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'services.bim' => [
            'title'       => 'BIM Modeling and Revit Services | Architive',
            'description' => 'BIM and Revit services for architects and project teams, including CAD to BIM, scan to BIM, Revit families, model updates and documentation.',
            'image'       => 'assets/img/og/bim-scan.jpg',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'services.cad' => [
            'title'       => 'CAD Drafting and Permit Drawing Support | Architive',
            'description' => 'CAD drafting for architects, interior designers and contractors, including plans, elevations, sections, PDF to DWG, redlines and permit-support packages.',
            'image'       => 'assets/img/og/cad-permit.jpg',
            'sitemap'     => [0.9, 'monthly'],
        ],
        'permit-revisions' => [
            'title'       => 'Permit Drawing Revisions: Fix City Comments | Architive',
            'description' => 'Upload your drawings and city comment letter, answer a few questions and get an estimated cost before sending your enquiry. Permit revision drafting by Architive.',
            'image'       => 'assets/img/og/cad-permit.jpg',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'services.outsourcing' => [
            'title'       => 'Architectural Production Support for Design Firms | Architive',
            'description' => 'Flexible visualization, Revit and CAD production support for architecture and interior design firms, delivered to your standards and schedule.',
            'image'       => 'assets/img/og/bim-steel-structure.jpg',
        ],
        'collaborations.index' => [
            'title'       => 'Architectural Production Collaborations | Architive',
            'description' => 'Selected Architive collaborations across visualization, Revit production support and CAD drafting for design and development teams.',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'process' => [
            'title'       => 'How Architive Projects Work',
            'description' => 'Share your files, receive a clear scope and quotation, review progress at agreed stages and receive final visualization, Revit or CAD deliverables.',
            'image'       => 'assets/img/og/cad-plan-pen.jpg',
            'sitemap'     => [0.8, 'monthly'],
        ],
        'team' => [
            'title'       => 'The Architive Team | Visualization, Revit and CAD Specialists',
            'description' => 'Meet the studio structure behind Architive: visualization, Revit and CAD specialists working as one team with a named point of contact.',
            'image'       => 'assets/img/og/developer-tower-frame.jpg',
            'robots'      => 'noindex,follow',   // team page is parked until the client supplies team portraits
        ],
        'faqs' => [
            'title'       => 'Architive FAQs | Pricing, Revisions, NDAs and Files',
            'description' => 'Answers on office standards, free starts, permit drawing support, pricing, revisions, NDAs and deliverable formats from Architive.',
            'sitemap'     => [0.7, 'monthly'],
        ],
        'contact' => [
            'title'       => 'Contact Architive | Start Your Project',
            'description' => 'Share your files, deadline and outcome. Architive reviews the information and recommends a practical scope during a free consultation.',
            'image'       => 'assets/img/og/contact-glass.jpg',
            'sitemap'     => [0.9, 'yearly'],
        ],
        'privacy' => [
            'title'       => 'Privacy Policy | Architive',
            'description' => 'How Architive collects, uses and protects the information you share when you contact us or browse this website.',
            'sitemap'     => [0.3, 'yearly'],
        ],
        'terms' => [
            'title'       => 'Terms of Service | Architive',
            'description' => 'The terms that apply to your use of the Architive website and to project enquiries.',
            'sitemap'     => [0.3, 'yearly'],
        ],
        'sitemap.html' => [
            'title'       => 'Site Map | Architive Pages and Services',
            'description' => 'A complete list of Architive pages: services, collaborations, process, FAQs and contact.',
            'sitemap'     => [0.2, 'monthly'],
        ],
    ],
];
